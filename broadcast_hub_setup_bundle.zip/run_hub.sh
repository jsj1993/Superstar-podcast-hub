#!/data/data/com.termux/files/usr/bin/bash

# Broadcast Hub Installer and Runtime Script (Full Stack)
APP_NAME="broadcast_hub_full"
APP_PORT=3000
ENV_FILE=".env"
CSV_FILE="broadcast_hub_structure.csv"

echo "----- [ Broadcast Hub: Full Stack Setup ] -----"

# Install dependencies
pkg update -y && pkg install nodejs yarn git -y

# Create project directory
mkdir -p $APP_NAME/components $APP_NAME/pages/api $APP_NAME/public $APP_NAME/styles
cd $APP_NAME

# Generate package.json
cat > package.json <<EOF
{
  "name": "broadcast-hub",
  "version": "1.0.0",
  "private": true,
  "scripts": {
    "dev": "next dev -p $APP_PORT",
    "build": "next build",
    "start": "next start"
  },
  "dependencies": {
    "next": "^14.1.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0"
  },
  "devDependencies": {
    "tailwindcss": "^3.3.0",
    "autoprefixer": "^10.4.0",
    "postcss": "^8.4.0"
  }
}
EOF

# Setup TailwindCSS
npx tailwindcss init -p
cat > tailwind.config.js <<EOF
module.exports = {
  content: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {},
  },
  plugins: [],
}
EOF

cat > styles/globals.css <<EOF
@tailwind base;
@tailwind components;
@tailwind utilities;
EOF

# Create .env
cat > .env <<EOF
NEXT_PUBLIC_YOUTUBE_URL=https://www.youtube.com/@the1tunchi
NEXT_PUBLIC_FACEBOOK_URL=https://www.facebook.com/share/16UuVnmDhu/
NEXT_PUBLIC_BIGO_URL=https://slink.bigovideo.tv/dX5Fj5
EOF

# Create sample Next.js pages and components
echo "[+] Creating components and pages..."

cat > pages/index.js <<'JSX'
import StreamWindow from '../components/StreamWindow'
import ChatPanel from '../components/ChatPanel'
import AnalyticsPanel from '../components/AnalyticsPanel'

export default function Home() {
  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold mb-4">Broadcast Hub</h1>
      <StreamWindow />
      <div className="flex flex-col md:flex-row gap-4 mt-4">
        <ChatPanel />
        <AnalyticsPanel />
      </div>
    </main>
  )
}
JSX

cat > components/StreamWindow.js <<'JSX'
import { useState } from 'react'
export default function StreamWindow() {
  const [platform, setPlatform] = useState('YOUTUBE')
  const links = {
    YOUTUBE: process.env.NEXT_PUBLIC_YOUTUBE_URL,
    FACEBOOK: process.env.NEXT_PUBLIC_FACEBOOK_URL,
    BIGO: process.env.NEXT_PUBLIC_BIGO_URL
  }

  return (
    <div>
      <select onChange={e => setPlatform(e.target.value)} className="mb-2 p-2 border">
        <option value="YOUTUBE">YouTube</option>
        <option value="FACEBOOK">Facebook</option>
        <option value="BIGO">Bigo Live</option>
      </select>
      <iframe src={links[platform]} width="100%" height="300" allow="autoplay" />
    </div>
  )
}
JSX

cat > components/ChatPanel.js <<'JSX'
export default function ChatPanel() {
  return (
    <div className="flex-1 border p-2">
      <h2 className="font-semibold mb-2">Live Chat</h2>
      <div className="bg-gray-100 h-48 overflow-y-scroll p-2">Chat loading...</div>
    </div>
  )
}
JSX

cat > components/AnalyticsPanel.js <<'JSX'
export default function AnalyticsPanel() {
  return (
    <div className="flex-1 border p-2">
      <h2 className="font-semibold mb-2">Viewer Analytics</h2>
      <ul>
        <li>Current Viewers: 0</li>
        <li>Messages: 0</li>
        <li>Stream Uptime: 00:00</li>
      </ul>
    </div>
  )
}
JSX

cat > pages/_app.js <<'JSX'
import '../styles/globals.css'
export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}
JSX

# Install node packages
yarn install

# Start the dev server
yarn dev
